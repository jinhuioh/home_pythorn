data = []
N = int(input())
for i in range(N):
    a = int(input())
    data.append(a)
print(min(data), max(data))